package QuoddFeed.util;

public class BuildDate {

	public static String  BuildDate()
	{
		return null;
	}
	
}
